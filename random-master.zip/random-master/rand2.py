import os

def main():
        action = input()
        if (action == " time "): 
            print( os.time)
        elif ( action == "calculator"):
            print" what would you like to do"
            action2 = input()
            if (action2 == "addition" or "subtraction" or "add" ) : 
                if ( action2== "addition" or action == "add"):
                    print ( "how many numbers will you add")
                    numberof =  raw_input() (int)
                    numberof = numberof (int) 
		    numbers = []
                    for numberof in (0, numberof):
                      print("number")
		      numbers = numbers + (input() (int))
		      a = 0
		      sums = 0
		      for numberof in (0, numberof):
                        sums = sums + numbers[a]
                        a+= 1
                if ( action == "subtraction"):
                    print ( "how many numbers will you subtract")
                    numberof =  input() (int)
		    numbers = []
                    for numberof in (0, numberof):
                      print("numbers")
		      numbers = numbers + (input() (int))
		      a = 0
		      negsums = 0
		      highest = 0
		      for numberof in (0, numberof):
		          if ( highest < numbers[a]):
		              highest = numbers[a] 
		          a+=1 
		      
		  
		      for numberof in (0, numberof):
                        
                        
                        
                        a+= 1
                        
                        
                        
            elif( action == "proccessor"):
                done = 0
                while( done == 0 ): 
                    text = input()
                    